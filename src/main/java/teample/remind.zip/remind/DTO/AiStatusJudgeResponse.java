package teample.remind.DTO;

public record AiStatusJudgeResponse(
        STATUS status,
        String reason
) {
}
