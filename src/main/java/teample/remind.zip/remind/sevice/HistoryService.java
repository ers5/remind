package teample.remind.sevice;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.ai.ollama.OllamaEmbeddingModel;
import org.springframework.stereotype.Service;
import teample.remind.DTO.STATUS;
import teample.remind.DTO.UserRequestDTO;
import teample.remind.entity.UserHistory;
import teample.remind.repository.UserHistoryRepository;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@RequiredArgsConstructor
public class HistoryService {

    private final UserHistoryRepository userHistoryRepository;
    private final OllamaEmbeddingModel embeddingModel;
    private final ConvertService convertService;

    public UserHistory getHistory(UserRequestDTO dto) {

        String appName=dto.appName();
        String willPowerLevel = convertService.convertToWillpowerLevel(dto.currentStats().willPowerScore());
        String usageLevel = convertService.convertToUsageLevel(dto.currentStats());
        Integer requestMinute = extractMinutes(dto.userInput());
        float[] vector = embeddingModel.embed(dto.userInput());

        return userHistoryRepository.findCloserHistory(vector,appName,willPowerLevel,usageLevel,requestMinute)
                .filter(history->calculateCosineDistance(vector,history.getEmbedding())<0.1)
                .map(history->{
                    history.incrementCount();;
                    return userHistoryRepository.save(history);
                })
                .orElse(null);
    }

    private double calculateCosineDistance(float[] v1,float[] v2) {
        double dotProduct=0.0;
        double norm1=0.0;
        double norm2=0.0;
        for (int i = 0; i < v1.length; i++) {
            dotProduct+=v1[i]*v2[i];
            norm1 += Math.pow(v1[i], 2);
            norm2 += Math.pow(v2[i], 2);
        }
        double similarity=dotProduct/(Math.sqrt(norm1)*Math.sqrt(norm2));
        return 1-similarity;

    }
    @Transactional
    public UserHistory saveHistory(UserRequestDTO dto, STATUS status, String reason) {
        String willPowerLevel =
                convertService.convertToWillpowerLevel(dto.currentStats().willPowerScore());

        String usageLevel =
                convertService.convertToUsageLevel(dto.currentStats());

        float[] vector = embeddingModel.embed(dto.userInput());

        UserHistory history = new UserHistory(
                dto.appName(),
                dto.userInput(),
                willPowerLevel,
                usageLevel,
                status,
                reason,
                vector,
                extractMinutes(dto.userInput())
        );

        return userHistoryRepository.save(history);
    }

    private Integer extractMinutes(String input) {
        if(input==null || input.isBlank()) return null;

        Pattern pattern = Pattern.compile("(\\d+)\\s*(시간|분|초)");
        Matcher matcher = pattern.matcher(input);

        int totalMinute=0;
        boolean found=false;

        while (matcher.find()) {
            int value = Integer.parseInt(matcher.group(1));
            String unit = matcher.group(2);

            switch (unit) {
                case "시간" -> totalMinute += value * 60;
                case "분" -> totalMinute += value;
                case "초" -> totalMinute += (int)Math.ceil(value / 60.0);
            }
            found=true;
        }
        if (!found) return null;
        return totalMinute;
    }
}
