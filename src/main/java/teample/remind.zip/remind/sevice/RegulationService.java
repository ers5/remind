package teample.remind.sevice;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.stereotype.Service;
import teample.remind.DTO.AiStatusJudgeResponse;
import teample.remind.DTO.STATUS;
import teample.remind.DTO.UserRequestDTO;
import teample.remind.DTO.UserResponseDTO;
import teample.remind.entity.UserHistory;
import tools.jackson.databind.ObjectMapper;

import java.util.*;
@Service
@RequiredArgsConstructor
@Slf4j
public class RegulationService {

    private final HistoryService historyService;
    private final ChatModel chatModel;
    private final ConvertService convertService;
    private final ObjectMapper objectMapper;
    private final int MAXCOUNT=3;

    public AiStatusJudgeResponse judgeStatus(UserRequestDTO dto) {
        UserHistory history = historyService.getHistory(dto);
        if (history !=null) return new AiStatusJudgeResponse(history.getStatus(),history.getReason());
        String usage=convertService.convertToUsageLevel(dto.currentStats());
        String willPower=convertService.convertToWillpowerLevel(dto.currentStats().willPowerScore());
        String prompt=String.format("""
                너는 앱 사용 조절 판단기다.
                아래 입력을 보고 상태를 하나만 고르고 그렇게 판단한 이유를 reason에 담아줘
                
                상태:
                OPTIMAL=과사용이 아님
                WARNING=과사용이 살짝 존재
                OVERUSE=과사용 가능성이 많이 존재
                CRITICAL=과사용 확정
                
                앱: %s
                입력: %s
                의지력:%s
                앱 실행량:%s
                
                JSON만 출력:
                {"status":"OPTIMAL|WARNING|OVERUSE|CRITICAL","reason":"1~2문장"}
                """,dto.appName(),dto.userInput(),willPower,usage);

        for (int i = 0; i < MAXCOUNT; i++) {
            String result = chatModel.call(prompt);
            log.info("LLM 반환: "+result);

            try {
                String json = extractJson(result);
                AiStatusJudgeResponse response = objectMapper.readValue(json, AiStatusJudgeResponse.class);

                STATUS status = response.status();
                historyService.saveHistory(dto, status, response.reason());
                return new AiStatusJudgeResponse(status, response.reason());
            } catch (IllegalArgumentException e) {
                log.warn("LLM 응답을 파싱 실패:{} ",i+1,e);
            }
        }
        return new AiStatusJudgeResponse(STATUS.FAIL,"에러 발생");
    }

    private String extractJson(String result) {
        int start = result.indexOf("{");
        int end = result.indexOf("}");

        if (start == -1 || end == -1 || start > end) {
            throw new IllegalArgumentException("JSON 객체가 없습니다: " + result);
        }

        return result.substring(start, end + 1);
    }
    }

