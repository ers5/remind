package teample.remind.sevice;

import org.springframework.stereotype.Service;
import teample.remind.DTO.UserRequestDTO;

import java.util.*;
@Service
public class ConvertService {
    public String convertToWillpowerLevel(Integer score) {
        if (score<=50) return "LOW";
        else if (score<=80) return "MID";
        else return "HIGH";
    }

    public String convertToUsageLevel(UserRequestDTO.CurrentStats stats) {
        Integer count = stats.todayOpenAppCount();
        Integer accum = stats.accumUseApp();

        if(count<=3 && accum<=30) return "LOW";
        else if(count>7 || accum>60) return "HIGH";
        else return "MID";
    }
}
